STW configuration export: STW-Profile-LOW
Generated locally by STW Mod Configurator.
