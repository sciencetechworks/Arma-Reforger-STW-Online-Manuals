STW configuration export: STW-Profile
Generated locally by STW Mod Configurator.
